package com.darkedit.ai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.VideoView

class MainActivity : Activity() {
    private lateinit var preview: VideoView
    private lateinit var status: TextView
    private val pickVideoRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 12, 18)
        window.navigationBarColor = Color.rgb(15, 12, 18)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(Color.rgb(15, 12, 18))
        }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        body.addView(text("DARK EDIT AI", 28, Color.rgb(255, 65, 75), true))
        body.addView(text("Seu editor de vídeos", 14, Color.LTGRAY))
        body.addView(space(12))

        preview = VideoView(this).apply { setBackgroundColor(Color.rgb(36, 30, 42)) }
        body.addView(preview, LinearLayout.LayoutParams(-1, dp(190)))
        body.addView(button("＋  Escolher clipe") { openVideoPicker() })
        status = text("Nenhum clipe selecionado", 13, Color.LTGRAY)
        body.addView(status)
        body.addView(space(14))
        body.addView(text("FERRAMENTAS", 16, Color.WHITE, true))

        listOf(
            "Reverso automático", "Zoom", "CC / Color Correction", "CC Shake",
            "Overlays", "Flash e Glow", "Slow Motion", "Motion Blur"
        ).forEach { name ->
            body.addView(button(name) {
                status.text = "$name: ferramenta planejada; processamento ainda não implementado nesta versão."
            })
        }

        body.addView(space(14))
        body.addView(text("CONVERSE COM A DARK AI", 16, Color.WHITE, true))
        body.addView(text("Descreva o resultado que você quer no seu vídeo.", 13, Color.LTGRAY))
        val prompt = EditText(this).apply {
            hint = "Ex.: reverso, zoom, CC Shake e overlays"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(42, 34, 50))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            minLines = 3
        }
        body.addView(prompt, LinearLayout.LayoutParams(-1, dp(100)))
        body.addView(button("Enviar pedido") {
            val value = prompt.text.toString().trim()
            status.text = if (value.isEmpty()) "Escreva como deseja seu edit." else
                "Pedido anotado: $value. O chat com IA ainda precisa ser conectado."
        })
        body.addView(space(16))
        body.addView(text("Exportação 4K e efeitos reais serão adicionados após integrar e testar o motor de vídeo. A qualidade depende do clipe e do aparelho.", 12, Color.LTGRAY))
        setContentView(page)
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*" }
        startActivityForResult(Intent.createChooser(intent, "Escolher vídeo"), pickVideoRequest)
    }

    @Deprecated("Legacy picker callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoRequest && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                preview.setVideoURI(uri)
                preview.setOnPreparedListener { it.isLooping = true; preview.start() }
                status.text = "Clipe carregado. Escolha uma ferramenta."
            }
        }
    }

    private fun button(caption: String, action: () -> Unit): Button = Button(this).apply {
        text = caption
        isAllCaps = false
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(174, 35, 49))
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
