plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.darkedit.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.darkedit.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}

dependencies {
    implementation("androidx.media3:media3-transformer:1.5.1")
}
