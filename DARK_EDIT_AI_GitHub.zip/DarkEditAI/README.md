# DARK EDIT AI — Android starter

Projeto inicial Android nativo com identidade preta e vermelha.

## Gerar APK pelo celular com GitHub Actions
1. Envie todos os arquivos desta pasta para a raiz do repositório GitHub `Dark-Ai`.
2. Abra a aba **Actions** do repositório.
3. Se aparecer um aviso, habilite GitHub Actions.
4. Selecione **Build DARK EDIT AI APK** e toque em **Run workflow**.
5. Quando a execução terminar com sucesso, abra-a e baixe o artefato **DARK-EDIT-AI-debug-apk**.
6. Extraia o ZIP baixado e instale `app-debug.apk` no Android. Talvez seja necessário permitir instalação pelo navegador/gerenciador de arquivos.

## O que esta versão contém
- Tela inicial DARK EDIT AI.
- Seleção e pré-visualização de vídeo.
- Interface de ferramentas para reverso, zoom, CC, shake, overlays, flash/glow, slow motion e motion blur.
- Campo para descrever o edit desejado.

## Limitações
Esta é uma base visual/funcional inicial. Os botões de efeitos e o chat ainda são demonstrativos e não processam o vídeo. Reverso real, composição de efeitos, overlays, IA conectada e exportação 4K ainda precisam ser implementados e testados. A resolução final depende do vídeo de origem e do aparelho.
